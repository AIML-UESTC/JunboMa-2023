import torch.nn as nn
import torch
from blitz.utils import variational_estimator
from blitz.modules import BayesianConv2d, BayesianLinear, BayesianLSTM

@variational_estimator
class AlexNet(nn.Module):
    def __init__(self, num_classes=1000, init_weights=False):
        super(AlexNet, self).__init__()
        self.features = nn.Sequential(
            BayesianConv2d(3, 64, kernel_size=(11, 11)),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=5, stride=3),
            BayesianConv2d(64, 128, kernel_size=(11, 11)),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=5, stride=3),
            BayesianConv2d(128, 256, kernel_size=(11, 11)),
            nn.LeakyReLU(inplace=True),
            nn.MaxPool2d(kernel_size=5, stride=3),
            BayesianConv2d(256, 512, kernel_size=(11, 11)),
            nn.LeakyReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=1),
        )
        # self.lstm = BayesianLSTM(512, 1024, prior_sigma_1=1, prior_pi=1, posterior_rho_init=-3.0)
        self.classifier = nn.Sequential(
            BayesianLinear(512, 1024),
            BayesianLinear(1024, 100),
            BayesianLinear(100, num_classes)
        )
        if init_weights:
            self._initialize_weights()

    def forward(self, x):
        x = self.features(x)
        x = x.view(x.size(0), -1, 512)
        # x, _ = self.lstm(x)
        # x = x[:, -1, :]
        x = torch.flatten(x, start_dim=1)
        x = self.classifier(x)
        return x

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)
